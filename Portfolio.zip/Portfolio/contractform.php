<?php

if (isset($_POST['submit'])) {
	$name = $_POST['name'];
	$subject = $_POST['subject'];
	$mailFrom = $_POST['mail'];
	$message = $_POST['message'];

	$mailTo = "pori0001@edu.sde.dk";
	$headers = "From: ".$mailFrom;
	$txt = "Du har faeet en besked fra ".$name.".\n\n".$message;

	mail($mailTo, $subject, $txt, $headers);
	header("Location: kontakt.html");
}